package com.reviling.filamentandroid


import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.PagerAdapter


class CardPagerAdapter(private val views: List<CardSurfaceView>): PagerAdapter() {

    override fun getCount(): Int {
        return views.size
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        var view = views[position]
        container.addView(view)
        return view
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(views[position])
        views[position].tag = true
    }

    fun release() {
        views.forEach { v ->
            v.apply {
                release()
                (parent as? ViewGroup)?.removeView(this)
            }
        }
    }
}