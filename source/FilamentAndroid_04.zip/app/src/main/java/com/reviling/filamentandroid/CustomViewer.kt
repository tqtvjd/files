package com.reviling.filamentandroid

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.AssetManager
import android.util.Base64
import android.util.SparseArray
import android.view.Choreographer
import android.view.animation.LinearInterpolator
import androidx.core.animation.doOnEnd
import androidx.core.graphics.rotationMatrix
import androidx.core.graphics.values
import com.google.android.filament.*
import com.google.android.filament.android.UiHelper
import com.google.android.filament.filamat.MaterialBuilder
import com.google.android.filament.utils.*
import java.nio.ByteBuffer

class CustomViewer {

    private lateinit var choreographer: Choreographer
    private lateinit var modelViewer: ModelViewer
//    private var animator:ValueAnimator = ValueAnimator.ofInt(0, 180)

    private var mainuplator: Manipulator? = null

    private lateinit var material: Material
    private lateinit var materialInstance: MaterialInstance

    fun loadEntity() {
        choreographer = Choreographer.getInstance()
    }

    fun setSurfaceView(mSurfaceView: CardSurfaceView) {
        val uiHelper = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK).apply {
            isOpaque = false
        }
        val kDefaultObjectPosition = Float3(0.0f, 0.0f, -4.0f)
        mainuplator = Manipulator.Builder()
            .targetPosition(
                kDefaultObjectPosition.x,
                kDefaultObjectPosition.y,
                kDefaultObjectPosition.z
            )
            //.orbitHomePosition(0f, 0f, 1f)
            .viewport(mSurfaceView.width, mSurfaceView.height)
            //.flightStartPosition(0f, 4f, -1.25f)
            //.flightStartPosition(0f, 0f, 0f)
            .build(Manipulator.Mode.ORBIT)
        modelViewer = ModelViewer(mSurfaceView, uiHelper = uiHelper, manipulator = mainuplator)
//        mSurfaceView.setOnTouchListener(modelViewer)

        //Skybox and background color
        //without this part the scene'll appear broken
        /*with(modelViewer) {
            scene.skybox = Skybox.Builder().build(modelViewer.engine)
            scene.skybox?.setColor(1f, 1f, 1f, 1f) //White color
        }*/
        /*with(modelViewer.view) {
            bloomOptions.enabled = false
            fogOptions.enabled = false
            depthOfFieldOptions.enabled = false
            ambientOcclusionOptions.enabled = false
            temporalAntiAliasingOptions.enabled = false
            antiAliasing = View.AntiAliasing.FXAA
            setScreenSpaceRefractionEnabled(false)
            setShadowingEnabled(false)
            dynamicResolutionOptions.apply {
                enabled = false
                minScale = 1.0f
                maxScale = 1.0f
                homogeneousScaling = false
                quality = View.QualityLevel.LOW
            }
        }*/

        buildMaterial()
        setupMaterial()
    }

    fun loadGlb(context: Context, name: String) {
        val buffer = readAsset(context, "models/${name}.glb")
        modelViewer.apply {
            loadModelGlb(buffer)
            transformToUnitCube()
        }
    }

    fun loadGlb(context: Context, dirName: String, name: String) {
        val buffer = readAsset(context, "models/${dirName}/${name}.glb")
        modelViewer.apply {
            loadModelGlb(buffer)
            transformToUnitCube()
        }
    }

    fun loadGltf(context: Context, name: String) {
        val buffer = context.assets.open("models/${name}.gltf").use { input ->
            val bytes = ByteArray(input.available())
            input.read(bytes)
            ByteBuffer.wrap(bytes)
        }
        modelViewer.apply {
            loadModelGltf(buffer) { uri -> readAsset(context, "models/$uri") }
            transformToUnitCube()
        }
    }

    fun loadGltf(context: Context, dirName: String, name: String) {
        val buffer = context.assets.open("models/${dirName}/${name}.gltf").use { input ->
            val bytes = ByteArray(input.available())
            input.read(bytes)
            ByteBuffer.wrap(bytes)
        }
        modelViewer.apply {
            view.blendMode = View.BlendMode.TRANSLUCENT
            loadModelGltf(buffer) { uri ->
                val arr = uri.split(',')
                val encodeStr = arr[1]
                ByteBuffer.wrap(Base64.decode(encodeStr, Base64.DEFAULT))
                //readAsset(context, "models/${dirName}/$uri")
            }
            transformToUnitCube()
        }
    }

    private fun buildMaterial() {
        // MaterialBuilder.init() must be called before any MaterialBuilder methods can be used.
        // It only needs to be called once per process.
        // When your app is done building materials, call MaterialBuilder.shutdown() to free
        // internal MaterialBuilder resources.
        MaterialBuilder.init()

        val matPackage = MaterialBuilder()
            // By default, materials are generated only for DESKTOP. Since we're an Android
            // app, we set the platform to MOBILE.
            .platform(MaterialBuilder.Platform.MOBILE)

            // Set the name of the Material for debugging purposes.
            .name("Clear coat")

            // Defaults to LIT. We could change the shading model here if we desired.
            .shading(MaterialBuilder.Shading.LIT)

            // Add a parameter to the material that can be set via the setParameter method once
            // we have a material instance.
            .uniformParameter(MaterialBuilder.UniformType.FLOAT3, "baseColor")

            // Fragment block- see the material readme (docs/Materials.md.html) for the full
            // specification.
            .material("void material(inout MaterialInputs material) {\n" +
                    "    prepareMaterial(material);\n" +
                    "    material.baseColor.rgb = materialParams.baseColor;\n" +
                    "    material.roughness = 0.65;\n" +
                    "    material.metallic = 1.0;\n" +
                    "    material.clearCoat = 1.0;\n" +
                    "}\n")

            // Turn off shader code optimization so this sample is compatible with the "lite"
            // variant of the filamat library.
            .optimization(MaterialBuilder.Optimization.NONE)

            // When compiling more than one material variant, it is more efficient to pass an Engine
            // instance to reuse the Engine's job system
            .build(modelViewer.engine)

        if (matPackage.isValid) {
            val buffer = matPackage.buffer
            material = Material.Builder().payload(buffer, buffer.remaining()).build(modelViewer.engine)
        }

        // We're done building materials, so we call shutdown here to free resources. If we wanted
        // to build more materials, we could call MaterialBuilder.init() again (with a slight
        // performance hit).
        MaterialBuilder.shutdown()
    }

    private fun setupMaterial() {
        // Create an instance of the material to set different parameters on it
        materialInstance = material.createInstance()
        // Specify that our color is in sRGB so the conversion to linear
        // is done automatically for us. If you already have a linear color
        // you can pass it directly, or use Colors.RgbType.LINEAR
        materialInstance.setParameter("baseColor", Colors.RgbType.SRGB, 0.71f, 0.0f, 0.0f)
    }

    fun loadIndirectLight(context: Context, ibl: String) {
/*        @Entity val light2 = EntityManager.get().create()
        LightManager.Builder(LightManager.Type.SPOT)
            //.falloff(50f)
            //.sunAngularRadius(0.25f)
            .color(r, g, b)
            //.sunHaloFalloff(100f)
            .intensity(100_000f)
            .direction(0f, -0.50f, -1.0f) //
            .position(0f, 1f, 0f)
            .castShadows(true)
            .build(modelViewer.engine, light2)*/

        //modelViewer.camera.setExposure(16.0f, 1.0f / 125.0f, 100.0f)
        //modelViewer.scene.addEntity(light2)

        // Create the indirect light source and add it to the scene.
        val buffer = readAsset(context, "environments/venetian_crossroads_2k/${ibl}_ibl.ktx")
        KTX1Loader.createIndirectLight(modelViewer.engine, buffer).apply {
            intensity = 100_000f
            modelViewer.scene.indirectLight = this
        }

        LightManager.Builder(LightManager.Type.DIRECTIONAL)
            //.falloff(20f)
            //.sunAngularRadius(0.25f)
            //.color(10f, 10f, 10f)
            //.sunHaloFalloff(200f)
            //.intensityCandela(50_000f)
            .intensity(80_000f)
            .direction(0.15f, -0.4f, -1.2f)
            //.position(0f, -2.5f, 4f)
            .castShadows(true)
            //.castLight(true)
            .build(modelViewer.engine, modelViewer.light)

        //setupView(modelViewer.view)

        modelViewer.camera.setExposure(16f, 1.0f / 125.0f, 50.0f)
    }

    private fun setupView(view: View) {
        // on mobile, better use lower quality color buffer
        /*view.renderQuality = view.renderQuality.apply {
            hdrColorBuffer = View.QualityLevel.MEDIUM
        }

        // dynamic resolution often helps a lot
        view.dynamicResolutionOptions = view.dynamicResolutionOptions.apply {
            enabled = true
            quality = View.QualityLevel.MEDIUM
        }*/

        // MSAA is needed with dynamic resolution MEDIUM
        view.multiSampleAntiAliasingOptions = view.multiSampleAntiAliasingOptions.apply {
            enabled = true
        }

        // FXAA is pretty cheap and helps a lot
        view.antiAliasing = View.AntiAliasing.FXAA

        // ambient occlusion is the cheapest effect that adds a lot of quality
        view.ambientOcclusionOptions = view.ambientOcclusionOptions.apply {
            intensity = 20f
            radius = 5f
            enabled = true
        }
        // bloom is pretty expensive but adds a fair amount of realism
        /*view.bloomOptions = view.bloomOptions.apply {
            enabled = true
        }*/
    }

    fun loadEnvironment(context: Context, ibl: String) {
        // Create the sky box and add it to the scene.
        val buffer = readAsset(context, "environments/venetian_crossroads_2k/${ibl}_skybox.ktx")
        KTX1Loader.createSkybox(modelViewer.engine, buffer).apply {
            modelViewer.scene.skybox = this
        }
    }

    private fun readAsset(context: Context, assetName: String): ByteBuffer {
        val input = context.assets.open(assetName)
        val bytes = ByteArray(input.available())
        input.read(bytes)
        return ByteBuffer.wrap(bytes)
    }

    private val frameCallback = object : Choreographer.FrameCallback {
        private val startTime = System.nanoTime()
        override fun doFrame(currentTime: Long) {
            val seconds = (currentTime - startTime).toDouble() / 1_000_000_000
            choreographer.postFrameCallback(this)
            modelViewer.animator?.apply {
                if (animationCount > 0) {
                    applyAnimation(0, seconds.toFloat())
                }
                updateBoneMatrices()
            }
            modelViewer.render(currentTime)
        }
    }

    private fun Int.getTransform(): Mat4 {
        val tm = modelViewer.engine.transformManager
        return Mat4.of(*tm.getTransform(tm.getInstance(this), FloatArray(16)))
    }

    private fun Int.setTransform(mat: Mat4) {
        val tm = modelViewer.engine.transformManager
        tm.setTransform(tm.getInstance(this), mat.toFloatArray())
    }

    var mUsePage = 0

    private val transformArray = SparseArray<Mat4>()

    fun toggleTag() {
        mUsePage = 1 - mUsePage
    }

    fun transformTo(angle: Float) {
        //Log.e("TAG", "当前 $name: ${if(mFlag) "反->正" else "正->反"}")
        modelViewer.asset?.let { asset ->
            val tm = modelViewer.engine.transformManager
            if(transformArray.size() == 0) {
                var center = asset.boundingBox.center.let { v -> Float3(v[0], v[1], v[2]) }
                val halfExtent = asset.boundingBox.halfExtent.let { v -> Float3(v[0], v[1], v[2]) }
                val maxExtent = 2.0f * max(halfExtent)
                val scaleFactor = 2.0f / maxExtent
                center -= Float3(0.0f, 0.0f, -4.0f) / scaleFactor
                transformArray[0] = scale(Float3(scaleFactor)) * translation(-center)
                transformArray[1] = transformArray[0] * rotation(Float3(0f, 1f, 0f), 180f)
            }
            val transform = transformArray[mUsePage] * rotation(Float3(0f, 1f, 0f), angle)
            tm.setTransform(tm.getInstance(asset.root), transpose(transform).toFloatArray())
        }
    }

    /**
     * 重置状态
     */
    fun reset() {
        if(mUsePage != 0) {
            modelViewer.transformToUnitCube()
            mUsePage = 0
        }
    }

    fun startAnimation() {
        /*modelViewer.asset?.apply {
            val rootTransform = this.root.getTransform()
            val transform = rootTransform * rotation(Float3(0f, 1f, 0f), 1f)
            this.root.setTransform(transform)
        }*/
        // Animate the triangle
        val animator = ValueAnimator.ofFloat(0f, 180f)
        animator.interpolator = LinearInterpolator()
        animator.duration = 300
        animator.repeatCount = 0
        animator.addUpdateListener { a ->
            transformTo(a.animatedValue as Float)
        }
        animator.doOnEnd {
            toggleTag()
        }
        animator.start()
    }

    fun onResume() {
        choreographer.postFrameCallback(frameCallback)
    }

    fun onPause() {
        choreographer.removeFrameCallback(frameCallback)
    }

    fun onDestroy() {
        choreographer.removeFrameCallback(frameCallback)
    }
}