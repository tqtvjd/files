package com.reviling.filamentandroid

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import androidx.viewpager.widget.ViewPager

class CardViewPager(context: Context, attrs: AttributeSet?) : ViewPager(context, attrs) {

    init {
        offscreenPageLimit = 2
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        doInit()
    }

    private fun doInit() {
        val array = arrayListOf<CardSurfaceView>()
        for (i in 0..2) {
            val view = CardSurfaceView(context, null)
            view.setCard("b${i + 1}")
            array.add(view)
        }
        adapter = CardPagerAdapter(array)

        setPageTransformer(true) { page, position ->
            (page as? CardSurfaceView)?.transform(180f *  position)
            Log.e("TAG", "变化 f: $position")
        }

        addOnPageChangeListener(object: SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                array.forEachIndexed { index, cardSurfaceView ->
                    if(index != position) {
                        cardSurfaceView.reset()
                    }
                }
            }
        })
    }
}