package com.reviling.filamentandroid

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetManager
import android.util.AttributeSet
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.SurfaceView

class CardSurfaceView(context: Context?, attrs: AttributeSet?) :
    SurfaceView(context, attrs) {

    private var customViewer: CustomViewer = CustomViewer()

    private var gltfName: String? = null

    private val gestureDetectorListener by lazy {
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent?): Boolean {
                swipeOtherSide()
                Log.e("TAG", "onSingleTapUp")
                return true
            }
        }
    }

    fun setCard(name: String) {
        gltfName = name
        with(customViewer) {
            if(context == null) return@with
            loadEntity()
            setSurfaceView(this@CardSurfaceView)

            //directory and model each as param
            //loadGlb(this@MainActivity, "grogu", "grogu")
            gltfName?.let {
                loadGltf(context, "warcraft", it)
            }

            //directory and model as one
            //loadGlb(this@MainActivity, "grogu/grogu")

            //Enviroments and Lightning (OPTIONAL)
            loadIndirectLight(context, "card_2d") //venetian_crossroads_2k
//            loadEnvironment(context, "studio021-4")
        }
        onResume()
    }

    fun transform(angle: Float) {
        customViewer.transformTo(angle)
    }

    fun reset() {
        customViewer.reset()
    }

    /*fun toggleTag() {
        customViewer.toggleTag()
    }*/

    //fun getPageIndex() = customViewer.mUsePage

    //卡旋转180度
    private fun swipeOtherSide() {
        Log.e("**********", "swipeOtherSide")
        customViewer.startAnimation()
    }

    private val gestureDetector by lazy {
        GestureDetector(context, gestureDetectorListener)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        release()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        gestureDetector.onTouchEvent(event)
        return true
    }

    private fun onResume() {
        customViewer.onResume()
    }

    private fun onPause() {
        customViewer.onPause()
    }

    fun release() {
        customViewer.onDestroy()
    }
}